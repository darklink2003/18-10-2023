<?php
$a=$_GET['correo'];
$b=$_GET['clave'];
?>
<a href="archivo1.php?correo=<?php echo $a?>&clave=<?php echo $b?>">VAYA</a>

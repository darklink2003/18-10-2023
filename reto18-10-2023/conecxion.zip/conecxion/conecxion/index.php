<html>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
    <?php include("conexion.php") ;
                //echo(productos($conexion,$producto));
                ?>
    </body>
    
</html>




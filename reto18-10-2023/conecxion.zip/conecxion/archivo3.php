<?php
$conexion = mysqli_connect('localhost','root','','db_ejemplo');